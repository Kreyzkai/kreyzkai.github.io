# IELTS Quest Print Pack — what's inside & how to use it

All A4, print at 100%. Designed black-and-white first (school photocopier safe); colour is a bonus. Japanese text is embedded — no missing-character boxes.

> **Unofficial study resource.** Not affiliated with, endorsed by, or approved by IELTS, the British Council, IDP, Cambridge, or any school. All scripts, questions and model answers are original practice material — not official IELTS questions. Practice scores are not IELTS band scores and cannot predict a test result. Created by a school ALT for his own students. Last reviewed: October 2026.

## The files

| File | Pages | Who | What it's for |
|---|---|---|---|
| `IELTS Quest Mini Workbook.pdf` | 6 | Students | The Quest Book. Page 1 has a QR strip — each code opens that lesson on the web page (`#mission1`…`#mission7`), plus __年 __組 __番 / date / name fields and a Try 1 + Try 2 chart |
| `IELTS Quest Mission Sheets.pdf` | 7 (1 per lesson) | Teacher prints, students write | Print *only today's sheet*. Class/No./Date/Name header, QR code, and an **exit ticket** strip (score · error code A/P/D/S/F · next goal) you can scan as students leave |
| `IELTS Quest Teacher Scripts and Key.pdf` | 2 | Teacher only | **No-device mode**: read-aloud Scripts A/B/C (normal speed, pause at punctuation, don't stress answers), full answer key with trap notes, error-code tally idea, five 10-minute lesson openers, differentiation |
| `IELTS Quest Passport and Cards.pdf` | 2 | Students | Two cut-out Passports (glue in notebook — the record that survives shared devices) + 6 cut-apart cards: Part 1 frame, Part 2 plan, Help phrases, Part 3 frame, Listening checks, 13-vs-30 stress |
| `IELTS Quest Test Day Journey.pdf` | 1 | Students + wall | The whole test day on one page: Book → Check in → Listening → Reading → Writing → Speaking → Scores |

## Three ways to run it

1. **With phones (home / BYOD):** students scan the QR on their sheet and do that lesson with audio + timers, writing keywords on paper. **The paper is the record** — the website saves nothing (no accounts, nothing stored on the page).
2. **No student devices (typical classroom):** play the audio from your computer *or* read from the Teacher Pack. Students work on the Mission Sheet. The exit ticket is your formative check — tally the class's error codes; the biggest letter is next lesson's opener.
3. **Paper only (homework / no internet):** Mini Workbook pages 1–6. Listening needs a reader (partner/family/teacher recording) — scripts are in the Teacher Pack on purpose, so answers aren't sitting in the student's book.

## Printing tips

- Mission Sheets: print single sheets, not the whole file. Hole-punch left margin is allowed for.
- Passport & Cards p.2: one set per pair, laminated, lasts the year.
- Answers live only in the Teacher Pack and the Mini Workbook's final page — keep the teacher file out of the student handout pile.
- PDFs are small (8–140 KB) for school Wi-Fi and the GitHub Pages upload.

## On the website

The 028 page has a two-level download area: one student button ("Quest Book — 6 pages"), an **Offline Study Pack (.zip)** for studying without internet, and a folded "For teachers" section with the other files. Lesson URLs (`…Reviewer.html#mission3`) are deep links — that is what every QR code points to. Keep the HTML filename exactly as it is, or the printed QR codes stop working.
