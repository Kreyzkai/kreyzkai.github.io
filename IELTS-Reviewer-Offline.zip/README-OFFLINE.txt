IELTS Reviewer (028) — OFFLINE STUDY PACK
==========================================

Unofficial study resource. Not affiliated with, endorsed by, or approved by IELTS,
the British Council, IDP, Cambridge, or any school. All practice material is original;
practice results are not IELTS band scores. Last reviewed: October 2026.

HOW TO USE THIS PACK WITHOUT INTERNET
-------------------------------------
1. Unzip this folder on the computer or tablet you will study on.
2. Open the file:   028 IELTS Listening Speaking Reviewer.html   (double-click it)
   - It opens in your normal web browser and works with no internet connection.
   - Keep the eight 028-script-*.mp3 files in the same folder as the HTML file:
     that is where the listening audio lives (Parts 1–4 across all 10 IELTS task types).
3. Voice recording: browsers only allow microphone recording on secure (https) pages,
   so the recorder is switched off when you open the file this way. Use your phone's
   voice recorder app instead and compare your answer with the model.
4. The PDFs in this folder are the paper materials (Quest Book, Mission Sheets,
   Teacher Scripts & Key, Passport & Cards, Test Day Map).

WHAT THIS PACK DOES NOT DO
--------------------------
- It does not save your answers. Nothing is stored and nothing is sent anywhere.
- It does not give you a band score. Practice results are not IELTS scores.
- It is an introduction. For full preparation use official IELTS materials and
  timed practice tests (ielts.org, British Council IELTS Ready).

If you are a student at the school, bring your questions to your teacher/ALT.
