IELTS ACADEMIC REVIEWER (028) — COMPLETE OFFLINE STUDY PACK (v4 Academic)
=========================================================================
HOW TO START (NO INTERNET OR LOGIN REQUIRED):
1. Extract/unzip this entire folder onto your computer or USB drive (do NOT open directly inside the unextracted ZIP window so audio files load properly).
2. Double-click `028 IELTS Listening Speaking Reviewer.html` to open it in Chrome, Edge, Safari, or Firefox.

WHAT IS INCLUDED IN THIS OFFLINE PACK (18 FILES TOTAL):
- `028 IELTS Listening Speaking Reviewer.html` — Full 4-skill IELTS Academic interactive reviewer + Grammar Boost + live timers + local voice recorder
- 8 Listening MP3 tracks (`028-script-a` through `028-script-h`) covering all 10 official IELTS Listening formats across Parts 1–4
- 3 Speaking Examiner MP3 tracks (`028-script-s1-part1.mp3`, `028-script-s2-part2.mp3`, `028-script-s3-part3.mp3`)
- All 5 Printable A4 PDFs (`Test Day Journey`, `Mini Workbook`, `Mission Sheets`, `Teacher Scripts and Key`, `Passport and Cards`)

Unofficial educational practice material — nothing is uploaded or saved online.
