IELTS Academic Reviewer (028) — OFFLINE STUDY PACK
==================================================

Unofficial IELTS Academic study resource. Not affiliated with, endorsed by, or approved by
IELTS, the British Council, IDP, Cambridge, or any school. All practice material is original;
practice results are not IELTS band scores. Last reviewed: October 2026.

HOW TO USE THIS PACK WITHOUT INTERNET
-------------------------------------
1. Unzip this folder on the computer or tablet you will study on.
2. Open the file:   028 IELTS Listening Speaking Reviewer.html   (double-click it)
   - It opens in your normal web browser and works with no internet connection.
   - Keep all eleven 028-script-*.mp3 files in the same folder as the HTML file:
     8 Listening tracks (Parts 1–4 across all 10 official task types) +
     3 Speaking Examiner tracks (Parts 1, 2 & 3).
3. Voice recording: browsers only allow microphone recording on secure (https) pages,
   so the recorder is switched off when you open the file offline via file://. Use your
   phone's voice recorder app instead and compare your answer with the Band 6 & 7.5+ models.
4. The PDFs in this folder are the paper materials (Quest Book, Mission Sheets,
   Teacher Scripts & Key, Passport & Cards, Test Day Map).

WHAT THIS PACK DOES NOT DO
--------------------------
- It does not save your answers. Nothing is stored and nothing is sent anywhere.
- It does not give you an official band score. Practice results are not IELTS scores.
- For full timed mock exams, combine this reviewer with official ielts.org sample tests.
